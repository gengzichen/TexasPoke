function nexthand(){

    $.ajax({
        url: "/nexthand",
        contentType: 'application/json',
        type: "GET",
        traditional: true,
        success: function(msg) {
            deletecard("public-card");
            deletecard("player-card");
            deletecard("dealer-card");
            addcard("dealer-card","back","margin-left:100px");
            addcard("dealer-card","back","margin-left:100px");
            addcard("player-card",msg.player_first_card,"margin-left:100px");
            addcard("player-card",msg.player_second_card,"margin-left:100px");
            change_dealer_bet(msg.dealer_bet);
            change_player_bet(msg.player_bet);
            change_player_coin(msg.player_coin);
            for(let action of msg.all_action){
                enabled(action);
                disable(action);
            }
            for(let action of msg.actions){
                enabled(action);
            }
            disable("nexthand");
            var a= document.getElementById("step");
            a.innerHTML="Dealer bet " + msg.dealer_bet;
            var br = document.createElement("br");
            a.appendChild(br);
            clearoutcome();
            
        },
        fail: function(msg) {
            alert("fail");
        }
    });
    
}
function fold(){
    var step= document.getElementById("step");
    step.append("you folded");

    $.ajax({
        url: "/fold",
        contentType: 'application/json',
        type: "GET",
        traditional: true,
        success: function(msg) {
            deletecard("public-card")
            for (let public_card of msg.public_card){
                addcard("public-card",public_card,"margin-left:50px");
            }
            deletecard("dealer-card")
            addcard("dealer-card",msg.dealer_first_card,"margin-left:100px");
            addcard("dealer-card",msg.dealer_second_card,"margin-left:100px");

            change_player_coin(msg.player_coin);

            var outcome =document.getElementById("outcome");
            outcome.innerHTML="Gameover,"+ msg.result;
            reset();
        },
        fail: function(msg) {
            alert("fail");
        }
    });

}
function check(){

    $.ajax({
        url: "/check",
        contentType: 'application/json',
        type: "GET",
        traditional: true,
        success: function(msg) {
            deletecard("public-card")
            for (let public_card of msg.public_card){
                addcard("public-card",public_card,"margin-left:50px");
            }

            // change_dealer_bet(msg.dealer_bet);
            // change_player_bet(msg.player_bet);
            change_player_coin(msg.player_coin);

            for(let action of msg.all_action){
                enabled(action);
                disable(action);
            }
            for(let action of msg.actions){
                enabled(action);
            }
            var a= document.getElementById("step");
            a.append("You checked.");
            var br = document.createElement("br");
            a.appendChild(br);

            if(msg.end==true){
                deletecard("public-card")
                for (let public_card of msg.public_card){
                    addcard("public-card",public_card,"margin-left:50px");
                }
                deletecard("dealer-card")
                addcard("dealer-card",msg.dealer_first_card,"margin-left:100px");
                addcard("dealer-card",msg.dealer_second_card,"margin-left:100px");

                change_player_coin(msg.player_coin);

                var outcome =document.getElementById("outcome");
                outcome.innerHTML="Gameover,"+ msg.result;
                reset();
            }
        },
        fail: function(msg) {
            alert("fail");
        }
    });
}
function call(){

    $.ajax({
        url: "/call",
        contentType: 'application/json',
        type: "GET",
        traditional: true,
        success: function(msg) {
            deletecard("public-card")
            for (let public_card of msg.public_card){
                addcard("public-card",public_card,"margin-left:50px");
            }
            change_dealer_bet(msg.dealer_bet);
            change_player_bet(msg.player_bet);
            change_player_coin(msg.player_coin);

            if(msg.end==false){
                for(let action of msg.all_action){
                    enabled(action);
                    disable(action);
                }
                for(let action of msg.actions){
                    enabled(action);
                }
                var a= document.getElementById("step");
                a.append("You called.");
                var br = document.createElement("br");
                a.appendChild(br);
            }
            else{
                
                deletecard("public-card")
                for (let public_card of msg.public_card){
                    addcard("public-card",public_card,"margin-left:50px");
                }
                deletecard("dealer-card")
                addcard("dealer-card",msg.dealer_first_card,"margin-left:100px");
                addcard("dealer-card",msg.dealer_second_card,"margin-left:100px");

                change_player_coin(msg.player_coin);

                var outcome =document.getElementById("outcome");
                outcome.innerHTML="Gameover,"+ msg.result;
                reset();
            
            }
        },
        fail: function(msg) {
            alert("fail");
        }
    });


}
function bet(){
    var bet_number = document.getElementById("bet_number").value;
    var max_bet = parseInt(document.getElementById("player_coin").innerText);
    var bet= parseInt(bet_number);
    if (bet<10){
        alert("The bet you enter is too small.Please enter again.");
    }
    else if(bet>max_bet){
        alert("The bet you enter is too large.Please enter again.");
    }
    else {
        var a= document.getElementById("step");
        a.append("You bet "+bet_number);
        var br = document.createElement("br");
        a.appendChild(br);
        $.ajax({
            url: "/bet",
            data: {'bet_number':bet_number},
            contentType: 'application/json',
            type: "GET",
            traditional: true,
            success: function(msg) {
                deletecard("public-card")
                for (let public_card of msg.public_card){
                    addcard("public-card",public_card,"margin-left:50px");
                }

                change_dealer_bet(msg.dealer_bet);
                change_player_bet(msg.player_bet);
                change_player_coin(msg.player_coin);

                for(let action of msg.all_action){
                    enabled(action);
                    disable(action);
                }
                for(let action of msg.actions){
                    enabled(action);
                }
                if(msg.end==true){
                    deletecard("public-card")
                    for (let public_card of msg.public_card){
                        addcard("public-card",public_card,"margin-left:50px");
                    }
                    deletecard("dealer-card")
                    addcard("dealer-card",msg.dealer_first_card,"margin-left:100px");
                    addcard("dealer-card",msg.dealer_second_card,"margin-left:100px");
    
                    change_player_coin(msg.player_coin);
    
                    var outcome =document.getElementById("outcome");
                    outcome.innerHTML="Gameover,"+ msg.result;
                    reset();
                }
            },
            fail: function(msg) {
                alert("fail");
            }
        });
    }
}
function minbet(){
    var a= document.getElementById("step");
    a.append("You bet 10.");
    var br = document.createElement("br");
    a.appendChild(br);
    $.ajax({
        url: "/minbet",
        contentType: 'application/json',
        type: "GET",
        traditional: true,
        success: function(msg) {
            deletecard("public-card")
            for (let public_card of msg.public_card){
                addcard("public-card",public_card,"margin-left:50px");
            }

            change_dealer_bet(msg.dealer_bet);
            change_player_bet(msg.player_bet);
            change_player_coin(msg.player_coin);

            for(let action of msg.all_action){
                enabled(action);
                disable(action);
            }
            for(let action of msg.actions){
                enabled(action);
            }
            if(msg.end==true){
                deletecard("public-card")
                for (let public_card of msg.public_card){
                    addcard("public-card",public_card,"margin-left:50px");
                }
                deletecard("dealer-card")
                addcard("dealer-card",msg.dealer_first_card,"margin-left:100px");
                addcard("dealer-card",msg.dealer_second_card,"margin-left:100px");

                change_player_coin(msg.player_coin);

                var outcome =document.getElementById("outcome");
                outcome.innerHTML="Gameover,"+ msg.result;
                reset();
            }
        },
        fail: function(msg) {
            alert("fail");
        }
    });
}
function allin(){
    var bet_number = document.getElementById("player_coin").innerText;
    var a= document.getElementById("step");
    a.append("You bet "+bet_number);
    var br = document.createElement("br");
    a.appendChild(br);
    $.ajax({
        url: "/allin",
        contentType: 'application/json',
        type: "GET",
        traditional: true,
        success: function(msg) {
            deletecard("public-card")
            for (let public_card of msg.public_card){
                addcard("public-card",public_card,"margin-left:50px");
            }

            change_dealer_bet(msg.dealer_bet);
            change_player_bet(msg.player_bet);
            change_player_coin(msg.player_coin);

            for(let action of msg.all_action){
                enabled(action);
                disable(action);
            }
            for(let action of msg.actions){
                enabled(action);
            }
            if(msg.end==true){
                deletecard("public-card")
                for (let public_card of msg.public_card){
                    addcard("public-card",public_card,"margin-left:50px");
                }
                deletecard("dealer-card")
                addcard("dealer-card",msg.dealer_first_card,"margin-left:100px");
                addcard("dealer-card",msg.dealer_second_card,"margin-left:100px");

                change_player_coin(msg.player_coin);

                var outcome =document.getElementById("outcome");
                outcome.innerHTML="Gameover,"+ msg.result;
                reset();
            }
        },
        fail: function(msg) {
            alert("fail");
        }
    });
}
function addcard(place,cardname,style){
    var setplace = document.getElementById(place);
    var para_img = document.createElement('img');
    para_img.setAttribute("src","../static/img/pukeImage/"+cardname+".jpg");
    para_img.setAttribute("style","width:80px;"+style);
    setplace.appendChild(para_img);
}
function deletecard(place){
    var deleteplace = document.getElementById(place);
    deleteplace.innerHTML="";
}
function change_dealer_bet(bet){
    var place = document.getElementById("dealer-text");
    if (bet==0){
        place.innerHTML="";
    }else{
        place.innerHTML=bet;
    }
}
function change_player_bet(bet){
    var place = document.getElementById("player-text");
    if (bet==0){
        place.innerHTML="";
    }else{
        place.innerHTML=bet;
    }
}
function change_player_coin(coin){
    var place = document.getElementById("player_coin");
    place.innerHTML=coin;
}
function disable(id_name){
    var a =document.getElementById(id_name);
    var d=document.createAttribute("disabled");
    a.attributes.setNamedItem(d);
}
function enabled(id_name){
    var a =document.getElementById(id_name);
    if (a.hasAttribute("disabled")){
        a.attributes.removeNamedItem("disabled");
    }
}
function reset(){
    enabled("nexthand");
    enabled("fold");
    enabled("call");
    enabled("minBet");
    enabled("bet");
    enabled("allIn");
    enabled("check");

    disable("fold");
    disable("call");
    disable("minBet");
    disable("bet");
    disable("allIn");
    disable("check");
}
function clearoutcome(){
    var a =document.getElementById("outcome");
    a.innerHTML="";
}
