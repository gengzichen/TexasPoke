from flask_restx import Api
from app import app

from app.api import Card, Dealer, Game , Player, RoyalCard
# from app.api import user.api

