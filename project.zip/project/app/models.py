from app import db, login
from werkzeug.security import generate_password_hash, check_password_hash
from flask_login import UserMixin

@login.user_loader
def load_user(id):
    return User.query.get(int(id))

class User(UserMixin, db.Model):
    __tablename__="users"
    id=db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(100))
    coin = db.Column(db.Integer)
    password = db.Column(db.String(128))
    last_login_time = db.Column(db.String(30))
    
    def set_password(self,password):
        self.password = generate_password_hash(password)
    
    def check_password(self,password):
        return check_password_hash(self.password,password)

    def __init__(self, username, password, coin, time):
        self.username = username
        self.set_password(password)
        self.coin = coin
        self.last_login_time = time

    def user_info(self):
        username=self.username
        coin = self.coin
        return [username,coin]

    def get_user_info(self):
        user_info={}
        user_info["username"]=self.username
        user_info["coin"]=self.coin
        return user_info

