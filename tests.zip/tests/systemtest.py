import unittest, os, time
from app import app, db
from app.models import User
from selenium import webdriver

basedir = os.path.abspath(os.path.dirname(__file__))


class SystemTest(unittest.TestCase):
  driver = None
  
  def setUp(self):
    self.driver = webdriver.Firefox(executable_path=os.path.join(basedir,'geckodriver'))

    if not self.driver:
      self.skipTest('Web browser not available')
    else:
        db.init_app(app)
        db.create_all()
        u1 = User(username='Elise',password="123456789",coin=10000,time="05/21/22")
        u2 = User(username='Alice',password="123abcdefg",coin=80000,time="03/21/22")
        db.session.add(u1)
        db.session.add(u2)
        db.session.commit()

        self.driver.maximize_window()
        self.driver.get('http://localhost:5000/')

  def tearDown(self):
    if self.driver:
      self.driver.close()
      db.session.query(User).delete()
      db.session.commit()
      db.session.remove()
 
  def test_register(self):
    s = User.query.get(1)
    self.assertEqual(s.username,'Elise',msg='user exists in db')
    self.driver.get('http://127.0.0.1:5000/login')
    self.driver.implicitly_wait(5)
    username = self.driver.find_element_by_id('username')
    username.send_keys('Emma')
    password = self.driver.find_element_by_id('password')
    password.send_keys('asdfzxcv1234')

    time.sleep(1)
    self.driver.implicitly_wait(5)
    submit = self.driver.find_element_by_id('Register')
    submit.click()
    #check login success
    self.driver.implicitly_wait(5)
    time.sleep(1)



if __name__=='__main__':
  unittest.main(verbosity=2)