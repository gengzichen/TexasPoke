import unittest, os
from app import app, db
from app.models import User

class UserModelCase(unittest.TestCase):

    def setUp(self):
        basedir = os.path.abspath(os.path.dirname(__file__))
        app.config['SQLALCHEMY_DATABASE_URI']=\
            'sqlite:///'+os.path.join(basedir,'test.db')
        self.app = app.test_client()#creates a virtual test environment
        db.create_all()
        u1 = User(username='Elise',password="123456789",coin=10000,time="05/21/22")
        u2 = User(username='Alice',password="123abcdefg",coin=10000,time="03/21/22")

        db.session.add(u1)
        db.session.add(u2)
        db.session.commit()

    def tearDown(self):
        db.session.remove()
        db.drop_all()

    def test_password_hashing(self):
        s = User.query.get(1)
        self.assertFalse(s.check_password('1234567890'))
        self.assertTrue(s.check_password('123456789'))



if __name__=='__main__':
    unittest.main(verbosity=2)